#ifndef PidorDeal_H
#define PidorDeal_H
bool MenDeal = true;
#endif //boolEANS_H
