---
name: Module request
about: Request a new module
title: ''
labels: idea
assignees: ''

---
- [x] **My suggestion is not about illegal stuff, doesn't violate Telegram EULA and human rights.**
---

**Short description of idea**:

**If you have an existing implementation of this idea, e.g. in another userbot, attach it here**:

**Any additional information**:
