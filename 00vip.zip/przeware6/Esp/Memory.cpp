#include "Memory.hpp"
Memory g_Memory;
Config GlobalConfig;
JsonPreferences preferences;